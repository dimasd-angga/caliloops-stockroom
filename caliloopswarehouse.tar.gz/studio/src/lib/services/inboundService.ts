
import { firestore } from '@/lib/firebase';
import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  writeBatch,
  Timestamp,
  serverTimestamp,
  where,
  getDocs,
  orderBy,
  documentId,
  limit,
  getDoc,
  increment,
  runTransaction,
  QueryConstraint,
} from 'firebase/firestore';
import type { InboundShipment, Barcode, Unit, Pack, Sku } from '../types';
import { updateSkuPackCount } from './skuService';

const inboundShipmentsCollection = collection(firestore, 'inboundShipments');
const barcodesCollection = collection(firestore, 'barcodes');
const skusCollection = collection(firestore, 'skus');

// --- InboundShipment ---
export const subscribeToInboundShipments = (
  callback: (shipments: InboundShipment[]) => void,
  onError: (error: Error) => void
) => {
  const q = query(inboundShipmentsCollection, orderBy('createdAt', 'desc'));

  const unsubscribe = onSnapshot(
    q,
    (snapshot) => {
      const shipments = snapshot.docs.map(
        (doc) => ({ id: doc.id, ...doc.data() } as InboundShipment)
      );
      callback(shipments);
    },
    (error) => {
      console.error('Error subscribing to inbound shipments: ', error);
      onError(error);
    }
  );

  return unsubscribe;
}

export const addInboundShipment = async (
  shipmentData: Omit<InboundShipment, 'id' | 'createdAt' | 'updatedAt' | 'totalQuantity' | 'packs'>,
  packsData: { quantity: number; unit: Unit; note?: string; }[]
) => {
    const batch = writeBatch(firestore);
    const shipmentRef = doc(inboundShipmentsCollection);
    const skuRef = doc(skusCollection, shipmentData.skuId);

    const packs: Pack[] = packsData.map(pack => ({
        id: doc(collection(firestore, 'temp')).id,
        status: 'in-stock',
        isPrinted: false,
        ...pack
    }));
    
    const totalQuantity = packs.reduce((sum, pack) => sum + pack.quantity, 0);

    const newShipment: Omit<InboundShipment, 'id'> = {
        ...shipmentData,
        packs,
        totalQuantity,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
    };
    batch.set(shipmentRef, newShipment);

    // Helper function to calculate ITF-14 check digit
    const calculateCheckDigit = (code: string): string => {
        const digits = code.split('').map(Number);
        let sum = 0;
        for (let i = 0; i < digits.length; i++) {
            sum += digits[i] * (i % 2 === 0 ? 3 : 1);
        }
        const checkDigit = (10 - (sum % 10)) % 10;
        return checkDigit.toString();
    };

    // Barcode Generation for each pack
    packs.forEach((pack, index) => {
        const barcodeRef = doc(barcodesCollection);
        
        // Generate a 13-digit base from timestamp and index
        const time = new Date().getTime();
        const baseId = (time + index).toString(); // Ensure uniqueness for batch
        const thirteenDigits = baseId.slice(-13).padStart(13, '0');
        
        // Calculate and append check digit for ITF-14
        const checkDigit = calculateCheckDigit(thirteenDigits);
        const barcodeID = thirteenDigits + checkDigit;

        const newBarcode: Omit<Barcode, 'id'> = {
            inboundShipmentId: shipmentRef.id,
            packId: pack.id,
            skuId: shipmentData.skuId,
            storeId: shipmentData.storeId,
            skuName: shipmentData.skuName,
            skuCode: shipmentData.skuCode,
            barcodeID,
            quantity: pack.quantity,
            unit: pack.unit,
            createdAt: Timestamp.now(),
            updatedAt: Timestamp.now(),
            status: 'in-stock',
            isPrinted: false,
        };
        batch.set(barcodeRef, newBarcode);
    });

    // Update SKU remaining quantity and packs
    const skuDoc = await getDoc(skuRef);
    if (skuDoc.exists()) {
        batch.update(skuRef, { 
            remainingQuantity: increment(totalQuantity),
            remainingPacks: increment(packs.length),
        });
    }

    await batch.commit();
    return shipmentRef.id;
};

export const getShipmentsBySku = async (skuId: string): Promise<InboundShipment[]> => {
    const q = query(inboundShipmentsCollection, where('skuId', '==', skuId), orderBy('createdAt', 'desc'));
    const shipmentSnapshot = await getDocs(q);
    const shipments = shipmentSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as InboundShipment));

    if (shipments.length === 0) {
        return [];
    }

    // Get all pack IDs from all shipments
    const packIds = shipments.flatMap(s => s.packs.map(p => p.id));
    
    if (packIds.length === 0) {
        return shipments;
    }

    // Fetch all barcodes for these packs in a single query
    const barcodesQuery = query(barcodesCollection, where('packId', 'in', packIds));
    const barcodeSnapshot = await getDocs(barcodesQuery);
    const barcodesMap = new Map<string, Barcode>();
    barcodeSnapshot.forEach(doc => {
        const barcode = { id: doc.id, ...doc.data() } as Barcode;
        barcodesMap.set(barcode.packId, barcode);
    });
    
    // Attach barcodeId and status to each pack
    shipments.forEach(shipment => {
        shipment.packs.forEach(pack => {
            const barcode = barcodesMap.get(pack.id);
            if (barcode) {
                pack.barcodeId = barcode.id;
                pack.status = barcode.status; // Sync pack status with barcode status
                pack.isPrinted = barcode.isPrinted;
            }
        });
    });

    return shipments;
}


export const deleteShipment = async (id: string): Promise<void> => {
    // Also delete associated barcodes
    const q = query(barcodesCollection, where('inboundShipmentId', '==', id));
    const barcodeSnapshot = await getDocs(q);
    const batch = writeBatch(firestore);
    barcodeSnapshot.forEach(doc => {
        batch.delete(doc.ref);
    });
    const shipmentDoc = doc(firestore, 'inboundShipments', id);
    batch.delete(shipmentDoc);
    await batch.commit();
};


// --- Barcode ---
export const subscribeToBarcodesForPack = (
  packId: string,
  callback: (barcodes: Barcode[]) => void,
  onError: (error: Error) => void
) => {
  const q = query(barcodesCollection, where('packId', '==', packId));

  const unsubscribe = onSnapshot(
    q,
    (snapshot) => {
      const barcodes = snapshot.docs.map(
        (doc) => ({ id: doc.id, ...doc.data() } as Barcode)
      );
      callback(barcodes);
    },
    (error) => {
      console.error("Error subscribing to barcodes: ", error);
      onError(error);
    }
  );

  return unsubscribe;
};

const enrichBarcodesWithShipmentData = async (barcodes: Barcode[]): Promise<Barcode[]> => {
    if (barcodes.length === 0) return [];
  
    const shipmentIds = [...new Set(barcodes.map(b => b.inboundShipmentId))];
    if (shipmentIds.length === 0) return barcodes;
  
    const shipmentsSnapshot = await getDocs(query(inboundShipmentsCollection, where(documentId(), 'in', shipmentIds)));
    const shipmentsMap = new Map<string, InboundShipment>();
    shipmentsSnapshot.forEach(doc => {
      shipmentsMap.set(doc.id, { id: doc.id, ...doc.data() } as InboundShipment);
    });
  
    return barcodes.map(barcode => {
      const shipment = shipmentsMap.get(barcode.inboundShipmentId);
      if (shipment) {
        return {
          ...barcode,
          supplier: shipment.supplier,
          poNumber: shipment.poNumber,
        };
      }
      return barcode;
    });
};

export const getBarcodesBySkuId = async (skuId: string, storeId: string): Promise<Barcode[]> => {
    const q = query(
        barcodesCollection, 
        where('skuId', '==', skuId), 
        where('storeId', '==', storeId),
        where('status', '==', 'in-stock')
    );
    const querySnapshot = await getDocs(q);
    const barcodes = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Barcode));
    return enrichBarcodesWithShipmentData(barcodes);
}

export const getBarcodesForShipment = async (shipmentId: string): Promise<Barcode[]> => {
    const q = query(barcodesCollection, where('inboundShipmentId', '==', shipmentId));
    const querySnapshot = await getDocs(q);
    const barcodes = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Barcode));
    return enrichBarcodesWithShipmentData(barcodes);
}

export const getBarcodesBySkuCode = async (skuCode: string, storeId: string): Promise<Barcode[]> => {
    const q = query(barcodesCollection, where('skuCode', '==', skuCode), where('storeId', '==', storeId));
    const querySnapshot = await getDocs(q);
    const barcodes = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Barcode));
    return enrichBarcodesWithShipmentData(barcodes);
}

export const getBarcodesByBarcodeIds = async (barcodeIds: string[], storeId: string): Promise<Barcode[]> => {
    if (barcodeIds.length === 0) return [];
    
    // Firestore 'in' queries are limited to 30 values.
    const chunks: string[][] = [];
    for (let i = 0; i < barcodeIds.length; i += 30) {
        chunks.push(barcodeIds.slice(i, i + 30));
    }
    
    const results: Barcode[] = [];
    
    for (const chunk of chunks) {
        // Corrected Query: Use 'barcodeID' field instead of documentId()
        const q = query(
            barcodesCollection, 
            where('barcodeID', 'in', chunk),
            where('storeId', '==', storeId)
        );
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach(doc => {
            results.push({ id: doc.id, ...doc.data() } as Barcode);
        });
    }

    return enrichBarcodesWithShipmentData(results);
}


export const getBarcode = async (id: string, storeId: string): Promise<Barcode | null> => {
    const docRef = doc(firestore, 'barcodes', id);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists() && docSnap.data().storeId === storeId) {
        let barcodeData = { id: docSnap.id, ...docSnap.data() } as Barcode;
        
        // Enrich with shipment data
        const enrichedBarcodes = await enrichBarcodesWithShipmentData([barcodeData]);
        barcodeData = enrichedBarcodes[0];

        return barcodeData;
    }
    return null;
}

export const getBarcodeByBarcodeID = async (barcodeID: string): Promise<Barcode | null> => {
    const q = query(barcodesCollection, where('barcodeID', '==', barcodeID), limit(1));
    const querySnapshot = await getDocs(q);
    if (!querySnapshot.empty) {
        const docSnap = querySnapshot.docs[0];
        let barcodeData = { id: docSnap.id, ...docSnap.data() } as Barcode;
        const enrichedBarcodes = await enrichBarcodesWithShipmentData([barcodeData]);
        return enrichedBarcodes[0];
    }
    return null;
};


export const updateBarcode = async (id: string, barcodeUpdate: Partial<Omit<Barcode, 'id'>>): Promise<void> => {
    const barcodeDocRef = doc(firestore, 'barcodes', id);
  
    await runTransaction(firestore, async (transaction) => {
      // --- 1. READS ---
      const barcodeDoc = await transaction.get(barcodeDocRef);
      if (!barcodeDoc.exists()) {
        throw new Error("Barcode to update not found");
      }
      const originalBarcode = barcodeDoc.data() as Barcode;

      let shipmentRef: any;
      let shipmentData: InboundShipment | null = null;
      if (originalBarcode.inboundShipmentId) {
        shipmentRef = doc(inboundShipmentsCollection, originalBarcode.inboundShipmentId);
        const shipmentDoc = await transaction.get(shipmentRef);
        if (shipmentDoc.exists()) {
          shipmentData = shipmentDoc.data() as InboundShipment;
        }
      }
      
      const skuRef = originalBarcode.skuId ? doc(skusCollection, originalBarcode.skuId) : null;

      // --- 2. WRITES ---
      // Update the barcode itself
      transaction.update(barcodeDocRef, { ...barcodeUpdate, updatedAt: Timestamp.now() });

      // If the update includes a status change, update the associated documents
      if (barcodeUpdate.status && originalBarcode.status !== barcodeUpdate.status) {
        const oldStatus = originalBarcode.status;
        const newStatus = barcodeUpdate.status;

        // Update the pack in the shipment
        if (shipmentRef && shipmentData) {
            const packs = shipmentData.packs.map(pack => 
                pack.id === originalBarcode.packId 
                ? { ...pack, status: newStatus } 
                : pack
            );
            transaction.update(shipmentRef, { packs });
        }
        
        // Update the SKU's remaining pack and quantity counts
        if (skuRef) {
            let packIncrement = 0;
            let quantityIncrement = 0;

            if (oldStatus === 'in-stock' && (newStatus === 'out-of-stock' || newStatus === 'lost')) {
                packIncrement = -1;
                quantityIncrement = -originalBarcode.quantity;
            } else if ((oldStatus === 'out-of-stock' || oldStatus === 'lost') && newStatus === 'in-stock') {
                packIncrement = 1;
                quantityIncrement = originalBarcode.quantity;
            }
            
            if (packIncrement !== 0 || quantityIncrement !== 0) {
                 transaction.update(skuRef, { 
                    remainingPacks: increment(packIncrement),
                    remainingQuantity: increment(quantityIncrement) 
                });
            }
        }
      }
    });
};

export const markBarcodesAsPrinted = async (barcodeIds: string[]) => {
    if (barcodeIds.length === 0) return;

    const batch = writeBatch(firestore);
    barcodeIds.forEach(id => {
        const barcodeRef = doc(barcodesCollection, id);
        batch.update(barcodeRef, { isPrinted: true });
    });
    await batch.commit();
};


export const deleteBarcode = async (id: string): Promise<void> => {
  const barcodeDoc = doc(firestore, 'barcodes', id);
  await deleteDoc(barcodeDoc);
};
